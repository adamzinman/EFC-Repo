"""
EFC x80 I/O card faceplates for Ignition Perspective 8.1 (8.3-safe)
Cards = Controls Standard rev H, Table 6.1:
  BMXDDI1602  BMXDDI3202K  BMXDDO1602  BMXDDO3202K  BMXDDO6402K  BMXAMI0810  BMXAMO0802  BMXART0814

Outputs (./dist):
  EFC_IOFaceplates.zip      Perspective project (parent EFC_Styles): faceplates, parts, rack overview, demo
  EFC_IO_UDTs.json          Card UDTs (OPC UA via BMENUA0100), import at the provider root
  EFC_IO_Demo_Tags.json     Memory-tag demo copies of the UDTs + a demo rack, import at the provider root

Each card UDT mirrors the Control Expert IODDTs it uses:
  Module/   -> T_GEN_MOD elements of the card variable  {Prefix}{ModSuffix}
  CHnn/     -> channel IODDT elements of                {Prefix}{ChSuffix}n
  CHnn/Doc  -> engineering data kept in Ignition (loop tag, description, scaling, spare)
  CHnn/HMI  -> derived helpers for the faceplate (scaled value, diagnostic text)
OPC item path = {NodePrefix}{Prefix}{ChSuffix}n.ELEMENT   e.g. ns=2;s=R0S5_CH3.VALUE
"""
import json, os, zipfile, datetime, random

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dist")
PROJECT, PARENT = "EFC_IOFaceplates", "EFC_Styles"
BASE = "com.inductiveautomation.perspective"
FP, PARTS = "IO/Faceplates", "IO/Parts"
TYPE_FOLDER, DEMO_TYPE_FOLDER, DEMO_RACK = "IO", "IO_Demo", "IO_Demo/Rack0"

def vh(px): return f"{round(px / 10.8, 3)}vh"

# ------------------------------------------------------------------ IODDT element lists
# Confirm these against the Control Expert data editor (expand one instance of each IODDT).
# Bits are read by element name, so no bit positions are hard-coded anywhere.
IODDT = {
    "T_DIS_IN_STD":   {"value": "Boolean", "bits": ["TRIP", "FUSE", "BLK", "INTERNAL_FLT", "CONF_FLT", "COM_FLT", "APPLI_FLT"]},
    "T_DIS_OUT_STD":  {"value": "Boolean", "bits": ["TRIP", "FUSE", "BLK", "INTERNAL_FLT", "CONF_FLT", "COM_FLT", "APPLI_FLT"]},
    "T_ANA_IN_BMX":   {"value": "Int4", "bits": ["LOWER_LIMIT", "UPPER_LIMIT", "SENSOR_FLT", "RANGE_FLT", "INTERNAL_FLT", "CONF_FLT", "COM_FLT", "APPLI_FLT"]},
    "T_ANA_OUT_BMX":  {"value": "Int4", "bits": ["ACT_WIRE_FLT", "RANGE_FLT", "INTERNAL_FLT", "CONF_FLT", "COM_FLT", "APPLI_FLT"]},
    "T_ANA_IN_T_BMX": {"value": "Int4", "bits": ["LOWER_LIMIT", "UPPER_LIMIT", "SENSOR_FLT", "RANGE_FLT", "INTERNAL_FLT", "CONF_FLT", "COM_FLT", "APPLI_FLT"]},
}
GEN_MOD_BITS = ["MOD_FAIL", "CH_FLT", "BLK", "CONF_FLT", "NO_MOD"]
WORDS = ["EXCH_STS", "EXCH_RPT"]          # status words (refreshed by READ_STS)
NOT_FAULTS = {"LOWER_LIMIT", "UPPER_LIMIT"}  # shown as UNDER / OVER, not in the fault text

# kind: DI / DO / AI / AO / TEMP
CARDS = {
    "BMXDDI1602":  dict(kind="DI", n=16, ioddt="T_DIS_IN_STD",   desc="16 DI · 24 VDC"),
    "BMXDDI3202K": dict(kind="DI", n=32, ioddt="T_DIS_IN_STD",   desc="32 DI · 24 VDC positive logic"),
    "BMXDDO1602":  dict(kind="DO", n=16, ioddt="T_DIS_OUT_STD",  desc="16 DO · 24 VDC transistor"),
    "BMXDDO3202K": dict(kind="DO", n=32, ioddt="T_DIS_OUT_STD",  desc="32 DO · 24 VDC transistor"),
    "BMXDDO6402K": dict(kind="DO", n=64, ioddt="T_DIS_OUT_STD",  desc="64 DO · 24 VDC transistor"),
    "BMXAMI0810":  dict(kind="AI", n=8,  ioddt="T_ANA_IN_BMX",   desc="8 AI · 0–20 / 4–20 mA, ±10 V"),
    "BMXAMO0802":  dict(kind="AO", n=8,  ioddt="T_ANA_OUT_BMX",  desc="8 AO · isolated"),
    "BMXART0814":  dict(kind="TEMP", n=8, ioddt="T_ANA_IN_T_BMX", desc="8 RTD / TC · isolated"),
}
DEFAULT_SCALE = {"AI": (0, 10000, 0.0, 100.0, "%"), "AO": (0, 10000, 0.0, 100.0, "%"), "TEMP": (0, 10, 0.0, 1.0, "°C")}

# ------------------------------------------------------------------ tag builders
def opc(name, dt, item):
    return {"name": name, "tagType": "AtomicTag", "valueSource": "opc", "dataType": dt,
            "opcServer": {"bindType": "parameter", "binding": "{OPCServer}"},
            "opcItemPath": {"bindType": "parameter", "binding": "{NodePrefix}" + item}}
def mem(name, dt, value): return {"name": name, "tagType": "AtomicTag", "valueSource": "memory", "dataType": dt, "value": value}
def expr(name, dt, e): return {"name": name, "tagType": "AtomicTag", "valueSource": "expr", "dataType": dt, "expression": e}
def folder(name, tags): return {"name": name, "tagType": "Folder", "tags": tags}

def diag_expr(bits, rel=""):
    parts = [f'if({{[.]{rel}{b}}}, "{b} ", "")' for b in bits if b not in NOT_FAULTS]
    return " + ".join(parts) if parts else '""'

def plc_member(name, dt, item, demo, demo_val):
    return mem(name, dt, demo_val) if demo else opc(name, dt, item)

def module_folder(demo, dv):
    item = "{Prefix}{ModSuffix}."
    tags = [plc_member("MOD_ERROR", "Boolean", item + "MOD_ERROR", demo, dv.get("MOD_ERROR", False))]
    tags += [plc_member(w, "Int4", item + w, demo, 0) for w in WORDS]
    tags += [plc_member("MOD_FLT", "Int4", item + "MOD_FLT", demo, 0)]
    tags += [plc_member(b, "Boolean", item + b, demo, dv.get(b, False)) for b in GEN_MOD_BITS]
    tags.append(folder("HMI", [expr("DiagText", "String", diag_expr(GEN_MOD_BITS, "../"))]))
    return folder("Module", tags)

def channel_folder(card, i, demo, dv):
    c = CARDS[card]; spec = IODDT[c["ioddt"]]; kind = c["kind"]
    item = "{Prefix}{ChSuffix}" + str(i) + "."
    tags = [plc_member("VALUE", spec["value"], item + "VALUE", demo, dv.get("VALUE", False if spec["value"] == "Boolean" else 0)),
            plc_member("CH_ERROR", "Boolean", item + "CH_ERROR", demo, dv.get("CH_ERROR", False))]
    tags += [plc_member(w, "Int4", item + w, demo, 0) for w in WORDS]
    tags += [plc_member(b, "Boolean", item + b, demo, dv.get(b, False)) for b in spec["bits"]]
    doc = [mem("LoopTag", "String", dv.get("LoopTag", "")), mem("Description", "String", dv.get("Description", "")),
           mem("Spare", "Boolean", dv.get("Spare", False))]
    hmi = [expr("DiagText", "String", diag_expr(spec["bits"], "../"))]
    if kind in DEFAULT_SCALE:
        rmin, rmax, emin, emax, units = DEFAULT_SCALE[kind]
        doc += [mem("Units", "String", dv.get("Units", units)), mem("RawMin", "Float8", rmin), mem("RawMax", "Float8", rmax),
                mem("EngMin", "Float8", dv.get("EngMin", emin)), mem("EngMax", "Float8", dv.get("EngMax", emax))]
        # TEMP: ART values arrive in 0.1 degrees, so RawMax 10 / EngMax 1 gives VALUE / 10
        hmi.append(expr("Scaled", "Float8",
            "{[.]../Doc/EngMin} + ({[.]../VALUE} - {[.]../Doc/RawMin}) * ({[.]../Doc/EngMax} - {[.]../Doc/EngMin})"
            " / if({[.]../Doc/RawMax} = {[.]../Doc/RawMin}, 1, {[.]../Doc/RawMax} - {[.]../Doc/RawMin})"))
    tags += [folder("Doc", doc), folder("HMI", hmi)]
    return folder(f"CH{i:02d}", tags)

def card_udt(card, demo=False, demo_vals=None):
    c = CARDS[card]; dv = demo_vals or {}
    tags = [expr("CardModel", "String", f'"{card}"'), expr("CardDesc", "String", f'"{c["desc"]}"'),
            expr("Rack", "Int4", "{Rack}"), expr("Slot", "Int4", "{Slot}"),
            module_folder(demo, dv.get("mod", {}))]
    tags += [channel_folder(card, i, demo, dv.get(i, {})) for i in range(c["n"])]
    params = {"Rack": {"dataType": "Integer", "value": 0}, "Slot": {"dataType": "Integer", "value": 0}}
    if not demo:
        params.update({"OPCServer": {"dataType": "String", "value": "BMENUA0100"},
                       "NodePrefix": {"dataType": "String", "value": "ns=2;s="},
                       "Prefix": {"dataType": "String", "value": ""},
                       "ChSuffix": {"dataType": "String", "value": "_CH"},
                       "ModSuffix": {"dataType": "String", "value": "_MOD"}})
    return {"name": card, "tagType": "UdtType", "parameters": params, "tags": tags,
            "documentation": f"{card} ({c['desc']}). Channels mirror IODDT {c['ioddt']}; Module mirrors T_GEN_MOD."}

# ------------------------------------------------------------------ demo data
LOOPS = {"DI": ["ZSO-101", "ZSC-101", "LSH-210", "PSL-305", "HS-401A", "HS-401B", "FS-118", "TSH-220", "XA-501", "ZSO-102", "ZSC-102", "PSH-306"],
         "DO": ["XV-101", "XV-102", "XV-103", "SOL-201", "SOL-202", "M-301", "M-302", "XY-401", "HORN-1", "BCN-1", "XV-104", "XV-105"]}
AI_DEMO = [("PT-305", "Comp 1 suction", "psig", 0, 100, 5212), ("PT-306", "Comp 1 discharge", "psig", 0, 3000, 6248),
           ("FT-118", "N2 supply flow", "SCFM", 0, 500, 0), ("LT-210", "Tank 210 level", "%", 0, 100, 4475),
           ("TT-220", "Bearing temp (4-20 mA)", "°F", 0, 250, 2440), ("AT-501", "O2 analyzer", "%", 0, 25, 4)]
AO_DEMO = [("FCV-118", "N2 flow valve", 6200), ("PCV-306", "Discharge back-pressure", 2500), ("SC-401", "Comp 1 VFD speed ref", 8750)]
TC_DEMO = [("TE-220A", "Bearing DE", 1486), ("TE-220B", "Bearing NDE", 1510), ("TE-305", "Suction gas", 203),
           ("TE-306", "Discharge gas", 0), ("TE-410", "Cooling water in", 219), ("TE-411", "Cooling water out", 284)]
DEMO_RACK_CARDS = [("R0S2", "BMXDDI3202K", 2), ("R0S3", "BMXDDO1602", 3), ("R0S4", "BMXDDO3202K", 4),
                   ("R0S5", "BMXAMI0810", 5), ("R0S6", "BMXAMO0802", 6), ("R0S7", "BMXART0814", 7),
                   ("R0S8", "BMXDDI1602", 8), ("R0S9", "BMXDDO6402K", 9)]

def demo_vals(card):
    c = CARDS[card]; k = c["kind"]; rnd = random.Random(card); dv = {}
    if k in ("DI", "DO"):
        used = min(c["n"] - 3, 12 if c["n"] == 16 else c["n"] - 6)
        for i in range(c["n"]):
            if i >= used: dv[i] = {"Spare": True}; continue
            lt = LOOPS[k][i % len(LOOPS[k])] + ("" if i < len(LOOPS[k]) else f"-{i}")
            dv[i] = {"LoopTag": lt, "Description": f"Demo {('input' if k == 'DI' else 'output')} {i}", "VALUE": rnd.random() < 0.45}
        bad = 6 if k == "DI" else 2
        dv[bad].update({"CH_ERROR": True, "TRIP" if k == "DO" else "FUSE": True})
    elif k == "AI":
        for i in range(8):
            if i >= len(AI_DEMO): dv[i] = {"Spare": True}; continue
            lt, d, u, lo, hi, raw = AI_DEMO[i]
            dv[i] = {"LoopTag": lt, "Description": d, "Units": u, "EngMin": lo, "EngMax": hi, "VALUE": raw}
        dv[2].update({"CH_ERROR": True, "SENSOR_FLT": True, "LOWER_LIMIT": True})
        dv["mod"] = {"MOD_ERROR": True, "CH_FLT": True}
    elif k == "AO":
        for i in range(8):
            if i >= len(AO_DEMO): dv[i] = {"Spare": True}; continue
            lt, d, raw = AO_DEMO[i]; dv[i] = {"LoopTag": lt, "Description": d, "VALUE": raw}
    else:
        for i in range(8):
            if i >= len(TC_DEMO): dv[i] = {"Spare": True}; continue
            lt, d, raw = TC_DEMO[i]; dv[i] = {"LoopTag": lt, "Description": d, "VALUE": raw}
        dv[3].update({"CH_ERROR": True, "SENSOR_FLT": True, "UPPER_LIMIT": True})
    return dv

def build_tag_files():
    prod = {"tags": [folder("_types_", [folder(TYPE_FOLDER, [card_udt(c) for c in CARDS])])]}
    demo_types = [card_udt(c, demo=True, demo_vals=demo_vals(c)) for c in CARDS]
    inst = [{"name": n, "tagType": "UdtInstance", "typeId": f"{DEMO_TYPE_FOLDER}/{m}",
             "parameters": {"Rack": {"dataType": "Integer", "value": 0}, "Slot": {"dataType": "Integer", "value": s}}}
            for n, m, s in DEMO_RACK_CARDS]
    demo = {"tags": [folder("_types_", [folder(DEMO_TYPE_FOLDER, demo_types)]),
                     folder("IO_Demo", [folder("Rack0", inst)])]}
    return prod, demo

# ------------------------------------------------------------------ Perspective helpers
def comp(ctype, name, props=None, position=None, children=None, pc=None, meta=None, events=None):
    c = {"type": ctype, "version": 0, "meta": {"name": name}, "position": position or {}, "props": props or {}}
    if meta: c["meta"].update(meta)
    if pc: c["propConfig"] = pc
    if children is not None: c["children"] = children
    if events: c["events"] = events
    return c
def label(name, classes, text="", position=None, pc=None, meta=None):
    return comp("ia.display.label", name, {"text": text, "style": {"classes": classes}}, position, pc=pc, meta=meta)
def flex(name, direction, children, classes="", position=None, justify="flex-start", align="stretch", wrap="nowrap", pc=None, events=None):
    return comp("ia.container.flex", name, {"direction": direction, "justify": justify, "alignItems": align, "wrap": wrap,
                                            "style": {"classes": classes}}, position, children, pc, events=events)
FIX = lambda b: {"basis": b, "grow": 0, "shrink": 0}
GROW = {"basis": "0", "grow": 1, "shrink": 1}
TIP = {"tooltip": {"enabled": True, "text": ""}}

def b_expr(e): return {"binding": {"type": "expr", "config": {"expression": e}}}
def b_prop(p): return {"binding": {"type": "property", "config": {"path": p}}}
def b_tag(ref, rel):
    return {"binding": {"type": "tag", "config": {"mode": "indirect", "tagPath": "{0}/" + rel,
                                                  "references": {"0": ref}, "fallbackDelay": 2.5}}}
def b_expr_script(e, script):
    return {"binding": {"type": "expr", "config": {"expression": e},
                        "transforms": [{"type": "script", "code": script}]}}
def script_event(code): return {"type": "script", "scope": "G", "config": {"script": code}}
def view(root, params, custom, pc, w, h):
    for p in params: pc[f"params.{p}"] = {"paramDirection": "input", "persistent": True}
    return {"custom": custom, "params": params, "propConfig": pc, "props": {"defaultSize": {"width": w, "height": h}}, "root": root}

NN = lambda p: f'if(isNull({p}), "", toStr({p}))'
CP = "{view.params.cardPath}"

def header_bar(card):
    c = CARDS[card]
    inst = f'substring({CP}, lastIndexOf({CP}, "/") + 1)'
    sub = f'{inst} + "   ·   Rack " + {NN("{view.custom.rack}")} + "  Slot " + {NN("{view.custom.slot}")}'
    health = ('if(!isGood({view.custom.modErr}), "State/Unknown", if({view.custom.modErr}, "State/Fault", "State/Running"))')
    htxt = ('if(!isGood({view.custom.modErr}), "COMMS?", if({view.custom.modErr}, "MODULE FAULT", "MODULE HEALTHY"))')
    close = comp("ia.input.button", "Close", {"text": "✕", "style": {"classes": "Button/Icon"}}, FIX("auto"),
                 events={"component": {"onActionPerformed": script_event("\tsystem.perspective.closePopup('')")}})
    return flex("Header", "row", [
        label("Model", "Text/Size/L Text/Weight/Bold", card, FIX("auto")),
        label("Desc", "Text/Size/S", c["desc"], FIX("auto")),
        label("Instance", "Text/Size/S Text/Mod/Ellipsis", "", GROW, pc={"props.text": b_expr(sub)}),
        label("ModHealth", "State/Running", "MODULE HEALTHY", FIX("auto"),
              pc={"props.text": b_expr(htxt), "props.style.classes": b_expr(health)}),
        close,
    ], "Container/PopupHeader", FIX("auto"), align="center")

def status_bar(kind):
    diag = 'if(len(' + NN("{view.custom.modDiag}") + ') > 0, "Module: " + {view.custom.modDiag}, "No module diagnostics active")'
    note = ("Status bits (TRIP, SENSOR_FLT, MOD_FAIL …) refresh only when the PLC runs READ_STS on the channel or module. "
            "VALUE, CH_ERROR and MOD_ERROR are live every scan.")
    kids = [label("ModDiag", "Text/Label", "", GROW, pc={"props.text": b_expr(diag)}),
            label("Note", "Text/Caption", "ⓘ READ_STS", FIX("auto"), meta={"tooltip": {"enabled": True, "text": note}})]
    if kind in ("DO", "AO"):
        kids.insert(1, label("RO", "Text/Caption", "Read-only: the PLC drives these outputs", FIX("auto")))
    return flex("StatusBar", "row", kids, "Container/Toolbar", FIX("auto"), align="center")

def card_custom_pc():
    return {"custom.modErr": b_tag(CP, "Module/MOD_ERROR"), "custom.modDiag": b_tag(CP, "Module/HMI/DiagText"),
            "custom.rack": b_tag(CP, "Rack"), "custom.slot": b_tag(CP, "Slot")}

INSTANCES = ("\tn = %d\n\tp = str(value or '')\n\tif not p:\n\t\treturn []\n"
             "\treturn [{'cardPath': p, 'ch': i, 'chFolder': 'CH%%02d' %% i, 'alt': (i %% 2 == 1)} for i in range(%d, %d)]")

def repeater(name, part, start, end, direction, position, extra=None):
    props = {"path": f"{PARTS}/{part}", "instances": [], "direction": direction, "wrap": "wrap" if direction == "row" else "nowrap",
             "justify": "flex-start", "alignItems": "flex-start", "alignContent": "flex-start",
             "useDefaultViewWidth": direction == "column", "useDefaultViewHeight": True,
             "elementPosition": {"basis": "12.5%", "grow": 0, "shrink": 0} if direction == "row" else {"basis": "auto", "grow": 0, "shrink": 0},
             "style": {"classes": ""}}
    if extra: props.update(extra)
    return comp("ia.display.flex-repeater", name, props, position,
                pc={"props.instances": b_expr_script(CP, INSTANCES % (end - start, start, end))})

# ------------------------------------------------------------------ discrete
def discrete_view(card):
    c = CARDS[card]; n = c["n"]; groups = n // 16
    word = "INPUTS" if c["kind"] == "DI" else "OUTPUTS"
    gviews = []
    for g in range(groups):
        a, b = g * 16, g * 16 + 16
        gviews.append(flex(f"Group{g}", "column", [
            label(f"GroupLbl{g}", "Text/Subheader", f"{word} {a:02d}–{b - 1:02d}", FIX("auto")),
            repeater(f"Tiles{g}", "DiscreteTile", a, b, "row", FIX("auto")),
        ], "Util/Pad/S", {"basis": "50%" if groups > 2 else "100%", "grow": 0, "shrink": 0}))
    body = flex("Body", "row", gviews, "Util/Pad/S", GROW, wrap="wrap", align="flex-start")
    root = flex("root", "column", [header_bar(card), status_bar(c["kind"]), body], "Container/Popup")
    w = 1620 if groups > 2 else 810
    h = 112 + (1 if groups == 1 else 2) * 190
    return view(root, {"cardPath": f"[default]{DEMO_RACK}/R0S2"}, {}, card_custom_pc(), w, h)

def discrete_tile():
    chPath = "{view.custom.chPath}"
    pc = {"custom.chPath": b_expr(f'{CP} + "/" + {{view.params.chFolder}}'),
          "custom.value": b_tag(chPath, "VALUE"), "custom.err": b_tag(chPath, "CH_ERROR"),
          "custom.loop": b_tag(chPath, "Doc/LoopTag"), "custom.desc": b_tag(chPath, "Doc/Description"),
          "custom.spare": b_tag(chPath, "Doc/Spare"), "custom.diag": b_tag(chPath, "HMI/DiagText")}
    spare, err = "coalesce({view.custom.spare}, false)", "coalesce({view.custom.err}, false)"
    tile_cls = f'if({spare}, "Container/Inset Util/BorderDashed", if({err}, "State/Fault", "Container/Card")) + " Util/Pad/S"'
    led_cls = (f'if({spare}, "", if(!isGood({{view.custom.value}}), "Indicator/LED/Unknown", if({err}, "Indicator/LED/Fault",'
               ' if({view.custom.value}, "Indicator/LED/On", "Indicator/LED/Off"))))')
    loop = f'if({spare}, "Spare", if(len({NN("{view.custom.loop}")}) > 0, {{view.custom.loop}}, "—"))'
    sub = f'if({spare}, "", if({err}, "FAULT " + {NN("{view.custom.diag}")}, {NN("{view.custom.desc}")}))'
    tip = (f'"CH " + numberFormat({{view.params.ch}}, "00") + "  " + {NN("{view.custom.loop}")} + "\\n" + {NN("{view.custom.desc}")}'
           f' + if(len({NN("{view.custom.diag}")}) > 0, "\\nDiagnostics: " + {{view.custom.diag}}, "")'
           ' + if(!isGood({view.custom.value}), "\\nBad OPC quality", "")')
    top = flex("Top", "row", [
        label("Ch", "Text/Size/XS", "CH 00", GROW, pc={"props.text": b_expr('"CH " + numberFormat({view.params.ch}, "00")')}),
        label("Led", "Indicator/LED/Off", "", FIX(vh(12)), pc={"props.style.classes": b_expr(led_cls)}),
    ], "", FIX("auto"), justify="space-between", align="center")
    inner = flex("Tile", "column", [
        top,
        label("Loop", "Text/Size/S Text/Weight/Bold Text/Mod/Ellipsis", "", FIX("auto"), pc={"props.text": b_expr(loop)}),
        label("Sub", "Text/Size/XXS Text/Mod/Ellipsis", "", FIX("auto"), pc={"props.text": b_expr(sub)}),
    ], "Container/Card Util/Pad/S", GROW, pc={"props.style.classes": b_expr(tile_cls), "meta.tooltip.text": b_expr(tip)})
    inner["meta"].update(TIP)
    root = flex("root", "column", [inner], "Util/Pad/S Util/Transparent")
    return view(root, {"cardPath": "", "ch": 0, "chFolder": "CH00", "alt": False}, {}, pc, 96, 70)

# ------------------------------------------------------------------ analog
COLS = {  # name: (header, basis px @1080, numeric)
    "Ch": ("Ch", 34, False), "Loop": ("Loop tag", 104, False), "Desc": ("Description", None, False),
    "Raw": ("Raw", 64, True), "Value": ("Value", 84, True), "Units": ("Units", 54, False),
    "Bar": ("Range", 118, False), "Flags": ("Limit", 62, False), "Health": ("Health", 84, False)}
ANALOG_COLS = {"AI": ["Ch", "Loop", "Desc", "Raw", "Value", "Units", "Bar", "Flags", "Health"],
               "AO": ["Ch", "Loop", "Desc", "Raw", "Value", "Units", "Bar", "Health"],
               "TEMP": ["Ch", "Loop", "Desc", "Raw", "Value", "Units", "Flags", "Health"]}
def col_pos(k): b = COLS[k][1]; return GROW if b is None else FIX(vh(b))

def analog_view(card):
    c = CARDS[card]; k = c["kind"]
    hdr = flex("ColHeader", "row", [label(f"H_{x}", "Table/Header" + (" Text/Mod/Right" if COLS[x][2] else ""), COLS[x][0], col_pos(x))
                                    for x in ANALOG_COLS[k]], "", FIX("auto"))
    rows = repeater("Rows", f"AnalogRow_{k}", 0, c["n"], "column", FIX("auto"))
    body = flex("Body", "column", [hdr, rows], "Util/Pad/M", GROW)
    root = flex("root", "column", [header_bar(card), status_bar(k), body], "Container/Popup")
    return view(root, {"cardPath": f"[default]{DEMO_RACK}/R0S5"}, {}, card_custom_pc(), 1040 if k != "TEMP" else 920, 112 + 34 + 8 * 34 + 24)

def analog_row(k):
    ch = "{view.custom.chPath}"
    pc = {"custom.chPath": b_expr(f'{CP} + "/" + {{view.params.chFolder}}'),
          "custom.raw": b_tag(ch, "VALUE"), "custom.err": b_tag(ch, "CH_ERROR"), "custom.val": b_tag(ch, "HMI/Scaled"),
          "custom.loop": b_tag(ch, "Doc/LoopTag"), "custom.desc": b_tag(ch, "Doc/Description"),
          "custom.spare": b_tag(ch, "Doc/Spare"), "custom.units": b_tag(ch, "Doc/Units"),
          "custom.emin": b_tag(ch, "Doc/EngMin"), "custom.emax": b_tag(ch, "Doc/EngMax"), "custom.diag": b_tag(ch, "HMI/DiagText")}
    if k != "AO":
        pc["custom.lo"] = b_tag(ch, "LOWER_LIMIT"); pc["custom.hi"] = b_tag(ch, "UPPER_LIMIT")
    spare, err = "coalesce({view.custom.spare}, false)", "coalesce({view.custom.err}, false)"
    good = "isGood({view.custom.raw})"
    fmt = '"#,##0.0"' if k != "AI" else 'if(abs(coalesce({view.custom.emax}, 100) - coalesce({view.custom.emin}, 0)) >= 1000, "#,##0", "#,##0.0#")'
    pct = ('max(0, min(100, (coalesce({view.custom.val}, 0) - coalesce({view.custom.emin}, 0)) * 100.0 / '
           'if(coalesce({view.custom.emax}, 1) = coalesce({view.custom.emin}, 0), 1, coalesce({view.custom.emax}, 1) - coalesce({view.custom.emin}, 0))))')
    cells = {
        "Ch": label("Ch", "Table/Cell", "0", col_pos("Ch"), pc={"props.text": b_expr("toStr({view.params.ch})")}),
        "Loop": label("Loop", "Table/Cell Text/Weight/Bold Text/Mod/Ellipsis", "", col_pos("Loop"),
                      pc={"props.text": b_expr(f'if({spare}, "—", {NN("{view.custom.loop}")})')}),
        "Desc": label("Desc", "Table/Cell Text/Mod/Ellipsis", "", col_pos("Desc"),
                      pc={"props.text": b_expr(f'if({spare}, "Spare", {NN("{view.custom.desc}")})')}),
        "Raw": label("Raw", "Table/CellNumeric Text/Code", "", col_pos("Raw"),
                     pc={"props.text": b_expr(f'if({spare} || isNull({{view.custom.raw}}), "", toStr({{view.custom.raw}}))')}),
        "Value": label("Value", "Table/CellNumeric Text/Weight/Bold Text/Size/M", "", col_pos("Value"),
                       pc={"props.text": b_expr(f'if({spare}, "", if({err}, "FAULT", if(isNull({{view.custom.val}}), "---", numberFormat({{view.custom.val}}, {fmt}))))'),
                           "props.style.classes": b_expr(f'"Table/CellNumeric Text/Weight/Bold Text/Size/M" + if(!{spare} && !{good}, " Value/BadQuality", if({err}, " Text/Color/Fault", ""))')}),
        "Units": label("Units", "Table/Cell Text/Units", "", col_pos("Units"),
                       pc={"props.text": b_expr(f'if({spare}, "", {NN("{view.custom.units}")})')}),
        "Bar": flex("BarCell", "row", [flex("Track", "row", [
                    label("Fill", "Bar/Fill", "", FIX("0%"), pc={"position.basis": b_expr(f'toStr({pct}) + "%"')})],
                    "Bar/Track", {"basis": vh(10), "grow": 1, "shrink": 0},
                    pc={"position.display": b_expr(f"!{spare} && !{err}")})], "Table/Cell", col_pos("Bar"), align="center"),
        "Flags": label("Flags", "Table/Cell Text/Status", "", col_pos("Flags"),
                       pc={"props.text": b_expr(f'if({spare}, "", if(coalesce({{view.custom.lo}}, false), "UNDER", if(coalesce({{view.custom.hi}}, false), "OVER", "")))')}),
        "Health": flex("HealthCell", "row", [label("Health", "State/Running", "OK", FIX("auto"), pc={
                    "props.text": b_expr(f'if({spare}, "SPARE", if(!{good}, "COMMS?", if({err}, "FAULT", "OK")))'),
                    "props.style.classes": b_expr(f'if({spare}, "State/OutOfService", if(!{good}, "State/Unknown", if({err}, "State/Fault", "State/Running")))'),
                    "meta.tooltip.text": b_expr(f'if(len({NN("{view.custom.diag}")}) > 0, "Diagnostics: " + {{view.custom.diag}}, "No channel diagnostics active")')},
                    meta=TIP)], "Table/Cell", col_pos("Health"), align="center"),
    }
    row = flex("root", "row", [cells[x] for x in ANALOG_COLS[k]], "Table/Row", align="center",
               pc={"props.style.classes": b_expr('if({view.params.alt}, "Table/Row Table/RowAlt", "Table/Row")')})
    return view(row, {"cardPath": "", "ch": 0, "chFolder": "CH00", "alt": False}, {}, pc, 1000, 34)

# ------------------------------------------------------------------ rack overview
BROWSE = """\tlog = system.util.getLogger("EFC_IO")
\tout = []
\tif not value:
\t\treturn out
\ttry:
\t\tres = system.tag.browse(str(value), {"tagType": "UdtInstance"}).getResults()
\texcept Exception as e:
\t\tlog.warn("Rack browse failed for %s: %s" % (value, e))
\t\treturn out
\tpaths = [str(r["fullPath"]) for r in res]
\tif not paths:
\t\treturn out
\tqv = system.tag.readBlocking([p + "/CardModel" for p in paths] + [p + "/Slot" for p in paths])
\tn = len(paths)
\tfor i, p in enumerate(paths):
\t\tmodel = qv[i].value
\t\tif not model:
\t\t\tcontinue
\t\tslot = qv[n + i].value
\t\tout.append({"cardPath": p, "model": str(model), "slot": slot if slot is not None else 99})
\treturn sorted(out, key=lambda c: c["slot"])"""

OPEN = """\tmodel = self.view.params.model
\tif not model:
\t\treturn
\tp = self.view.params.cardPath
\tsystem.perspective.openPopup("io_" + p, "%s/" + model, params={"cardPath": p},
\t\ttitle="", showCloseIcon=False, draggable=True, resizable=False, modal=False)""" % FP

def slot_tile():
    pc = {"custom.modErr": b_tag(CP, "Module/MOD_ERROR"), "custom.desc": b_tag(CP, "CardDesc"),
          "custom.diag": b_tag(CP, "Module/HMI/DiagText")}
    h_cls = 'if(!isGood({view.custom.modErr}), "State/Unknown", if({view.custom.modErr}, "State/Fault", "State/Running"))'
    h_txt = 'if(!isGood({view.custom.modErr}), "COMMS?", if({view.custom.modErr}, "FAULT", "HEALTHY"))'
    tile_cls = 'if(isGood({view.custom.modErr}) && {view.custom.modErr}, "State/Fault", "Container/Card") + " Util/Pad/S Util/Pointer"'
    inner = flex("Tile", "column", [
        label("Slot", "Text/Size/XS", "", FIX("auto"), pc={"props.text": b_expr('"Slot " + toStr({view.params.slot})')}),
        label("Model", "Text/Size/S Text/Weight/Bold", "", FIX("auto"), pc={"props.text": b_prop("view.params.model")}),
        label("Desc", "Text/Size/XS Text/Mod/Wrap", "", GROW, pc={"props.text": b_expr(NN("{view.custom.desc}"))}),
        label("Inst", "Text/Size/XXS Text/Mod/Ellipsis", "", FIX("auto"),
              pc={"props.text": b_expr(f'substring({CP}, lastIndexOf({CP}, "/") + 1)')}),
        label("Health", "State/Running", "HEALTHY", FIX("auto"), pc={"props.text": b_expr(h_txt), "props.style.classes": b_expr(h_cls)}),
    ], "Container/Card Util/Pad/S Util/Pointer", GROW,
        pc={"props.style.classes": b_expr(tile_cls),
            "meta.tooltip.text": b_expr(f'"Open faceplate" + if(len({NN("{view.custom.diag}")}) > 0, "\\nModule: " + {{view.custom.diag}}, "")')},
        events={"dom": {"onClick": script_event(OPEN)}})
    inner["meta"].update(TIP)
    root = flex("root", "column", [inner], "Util/Pad/S Util/Transparent")
    return view(root, {"cardPath": "", "model": "", "slot": 0}, {}, pc, 132, 150)

def rack_overview():
    pc = {"custom.cards": b_expr_script("{view.params.rackPath}", BROWSE)}
    title = 'substring({view.params.rackPath}, lastIndexOf({view.params.rackPath}, "/") + 1)'
    rep = comp("ia.display.flex-repeater", "Slots", {
        "path": f"{PARTS}/SlotTile", "instances": [], "direction": "row", "wrap": "wrap", "justify": "flex-start",
        "alignItems": "flex-start", "alignContent": "flex-start", "useDefaultViewWidth": True, "useDefaultViewHeight": True,
        "elementPosition": {"basis": "auto", "grow": 0, "shrink": 0}, "style": {"classes": ""}}, GROW,
        pc={"props.instances": b_prop("view.custom.cards")})
    root = flex("root", "column", [
        flex("Head", "row", [label("Title", "Text/Header", "", FIX("auto"), pc={"props.text": b_expr(f'"I/O Rack  " + {title}')}),
                             label("Hint", "Text/Caption", "Click a card to open its faceplate", GROW)],
             "Util/Pad/S", FIX("auto"), align="baseline"),
        rep], "Container/Panel")
    return view(root, {"rackPath": f"[default]{DEMO_RACK}"}, {"cards": []}, pc, 1200, 220)

def demo_view():
    emb = comp("ia.display.view", "Rack", {"path": "IO/RackOverview", "params": {"rackPath": f"[default]{DEMO_RACK}"}}, FIX(vh(220)))
    root = flex("root", "column", [
        label("Title", "Text/Title", "x80 I/O card faceplates — demo", FIX("auto")),
        label("Hint", "Text/Caption Text/Mod/Wrap",
              f"Demo tags: [default]{DEMO_RACK} (memory-tag copies of the card UDTs). Click a card. Slot 5 has a module fault, "
              "slot 2 ch 6, slot 3 ch 2 and slot 7 ch 3 have channel faults; dashed tiles are spares.", FIX("auto")),
        emb], "Container/Screen Util/Pad/L")
    return {"custom": {}, "params": {}, "props": {"defaultSize": {"width": 1400, "height": 400}}, "root": root}

# ------------------------------------------------------------------ writers
def resource_json(files):
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return json.dumps({"scope": "G", "version": 1, "restricted": False, "overridable": True, "files": files,
                       "attributes": {"lastModification": {"actor": "build_io.py", "timestamp": ts}}}, indent=2)

def all_views():
    v = {}
    for card, c in CARDS.items():
        v[f"{FP}/{card}"] = discrete_view(card) if c["kind"] in ("DI", "DO") else analog_view(card)
    v[f"{PARTS}/DiscreteTile"] = discrete_tile()
    for k in ("AI", "AO", "TEMP"): v[f"{PARTS}/AnalogRow_{k}"] = analog_row(k)
    v[f"{PARTS}/SlotTile"] = slot_tile()
    v["IO/RackOverview"] = rack_overview()
    v["IO/_Demo"] = demo_view()
    return v

def build():
    os.makedirs(OUT, exist_ok=True)
    views = all_views()
    zpath = os.path.join(OUT, f"{PROJECT}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json", json.dumps({"title": PROJECT, "description": "EFC x80 I/O card faceplates (IODDT-based)",
                                               "parent": PARENT, "enabled": True, "inheritable": True}, indent=2))
        for path, body in views.items():
            z.writestr(f"{BASE}/views/{path}/view.json", json.dumps(body, indent=2, ensure_ascii=False))
            z.writestr(f"{BASE}/views/{path}/resource.json", resource_json(["view.json"]))
    prod, demo = build_tag_files()
    json.dump(prod, open(os.path.join(OUT, "EFC_IO_UDTs.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(demo, open(os.path.join(OUT, "EFC_IO_Demo_Tags.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    return zpath, views

if __name__ == "__main__":
    z, v = build()
    print(z, len(v), "views")
