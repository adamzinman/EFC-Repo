# EFC Ignition Perspective Library

Ignition Perspective **8.1** HMI building blocks for the plant SCADA: the EFC_Styles style-class library, process-value templates, PID loop templates and their settings popup, navigation connector symbols, design notes, and the generators that build all of it. Everything follows ISA-101 (gray screens, color only for abnormal states) and the screen layout standard (1920×1080, sizes converted to `vh` so they scale).

Project folders are stored **unzipped** so changes show up as readable diffs. `tools/package.py` turns them into import-ready zips.

## Layout

```
projects/                 Ignition project source, one folder per project (project.json at each root)
  EFC_Styles/             166 style classes + stylesheet.css + Styles/_Catalog view        (generated)
  EFC_ProcessValues/      PV_StatusStrip, PV_RangeBar, _Demo + 36 PV style classes          (generated, parent EFC_Styles)
  PID_Loops/              Loop_B1_Bar, Loop_B2_Horizontal, Loop_B3_Sparkline, Loop_B4_Column,
                          Popups/LoopConfig, _Demo_Loops                                     (generated)
  PID_Compressor_Diaphragm/  Legacy add-on symbol view, superseded by PID_Symbols v5.1       (generated)
tags/                     Tag JSON to import in the Tag Browser
  PID_Loops/              PID_Loop UDT + 3 demo instances
  ProcessValues/          DDT_Process_Value_Demo UDT + 5 demo instances
symbols/                  Plain SVGs
  NavConnectors/          To/From navigation connector options A–D
  legacy/                 Diaphragm compressor add-on (superseded)
generators/               Python generators (the source of truth for everything generated)
  efc_styles/build_styles.py
  process_values/build_pv.py
  pid_loops/generate_loops.py
  nav_connectors/generate_nav_connectors.py
  compressor_addon/generate_compressor.py
  pid_symbols/active.py   Geometry + palette module for the PID_Symbols active templates (reference; see below)
mockups/                  HTML previews (open in a browser)
docs/                     Design notes, audits and indexes
tools/                    build_all.py, check_projects.py, package.py
dist/                     Build output (git-ignored)
```

## Workflow

Requires Python 3.8+ (standard library only).

```bash
python3 tools/build_all.py          # regenerate projects/, tags/, symbols/, mockups/ from the generators
python3 tools/check_projects.py     # static 8.1 import checks
python3 tools/package.py            # dist/<Project>_PROJECT.zip + dist/tags/
git add -A && git commit
```

To change something, edit the generator, run the three commands, review the diff, commit. Don't hand-edit files under `projects/` that a generator owns; the next build overwrites them. If you change a view in Designer instead, copy it back from the gateway (`data/projects/<Project>/...`) and port the change into the generator.

`build_all.py loops` (or `styles`, `nav`, `compressor`, `process_values`) rebuilds just one part.

Note: `build_styles.py` and `build_pv.py` stamp the current time into every `resource.json`, so a rebuild touches all of those files even when nothing else changed. The other generators use a fixed timestamp.

## Importing into Ignition

Gateway → Config → Projects → Import, using the zips from `dist/`, or in Designer use **File → Import** to bring views into the project you have open. Project zips must have `project.json` at the zip root; `package.py` does this.

1. `EFC_Styles_PROJECT.zip` first (other projects inherit from it).
2. `EFC_ProcessValues_PROJECT.zip` (parent `EFC_Styles`).
3. `PID_Loops_PROJECT.zip` (no parent; uses inline styles).
4. Tags: Tag Browser → Data Types → import the UDT JSON, then import the demo instances at the provider root.

Recommended inheritance chain: `EFC_Styles → EFC_ProcessValues → PID_Symbols → HMI` (one parent per project).

## What's in each part

| Part | Status | Docs |
|---|---|---|
| EFC_Styles | v5 (ISA-101 audit fixes), 166 classes | `docs/style-library.md`, `docs/style-class-index.md`, `docs/isa101-audit.md` |
| EFC_ProcessValues | v1.3, 100×50 cards; v1.1–1.3 not re-tested on the gateway | `docs/pv-display-notes.md`, `docs/pv-style-index.md` |
| PID_Loops | Built 2026-10-05; not yet tested on a gateway | `docs/pid-loop-templates.md` |
| Nav connectors | SVG options A–D; no option chosen yet | `mockups/nav-connectors.html` |
| PID_Symbols | v5.1 (16 active templates); **build files not in this repo yet** | `docs/pid-symbol-suite.md`, `docs/pid-v3-notes.md`, `docs/pid-symbol-index.md` (v2 views) |

### PID_Loops notes
- Template params: `tagPath` (instance of the `PID_Loop` UDT) and optional `label`. Clicking the card opens `PID/Popups/LoopConfig`.
- Enable tag history on `PV`, `SP` and `OUT` or the B3 sparkline and popup trend stay blank.
- UDT members are memory tags in the export; change them to OPC tags on the M580 PID block. Mode: 0 MAN, 1 AUTO, 2 CAS.
- The card's alarm outline compares PV with `AlmHi`/`AlmLo`; it doesn't read real alarm state yet.
- `preserveAspectRatio` changed from `xMidYMid meet` to `xMidYMid` (8.1 only accepts the bare value; found while building PID_Symbols v5.1). The zips shipped on 2026-10-05 still have the old value.
- These views use inline styles, not EFC_Styles classes, so they don't yet follow the style-library standard.

## Not in this repo yet

These were built in other sessions and their files aren't available here. Add them from your machine when you can:

- **PID_Symbols v5.1**: `PID_Symbols_PROJECT.zip`, `EFC_PID_Library_PROJECT.zip`, the 214 SVGs in `symbols/`, the tag JSON (`PID_Motor`, `PID_ControlValve`, `Valve_Discrete_Demo`, `PID_Demo_Instances`) and the generator folder (`build_v5.py`, `build_v3.py`, `build_v4.py`, `preview_v5.py`, `make_project_zip.py`, `check_81.py`, `v2/`). Unzip the project into `projects/PID_Symbols/` and put the generator next to `generators/pid_symbols/active.py`. Note that `active.py` here is the v3 module (transition gray `#D9D9D9`, dashed travel outline); v5.1 uses `#C4C4C4` and no dash, so take the current `active.py` from the v5.1 generator folder.
- Station faceplates, x80 I/O card faceplates, the diaphragm compressor screen and the Haskel pump faceplate.
