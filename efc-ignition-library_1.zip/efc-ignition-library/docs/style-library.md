# EFC Style Library — Ignition Perspective 8.1 (ISA-101 light gray)

160 Perspective style classes + a project stylesheet + a catalog view, packaged as an inheritable project.

## Files
| File | Use |
|---|---|
| `EFC_Styles.zip` | Perspective project: `style-classes/…`, `stylesheet/stylesheet.css`, view `Styles/_Catalog` |
| `style_preview.html` | Open in a browser to see every class (rendered at 1920×1080) |
| `style_index.md` | Every class path and what it's for |
| `build_styles.py` | Generator. Edit `PALETTE` / `TYPE_SCALE`, run `python3 build_styles.py`, re-import |

## Importing
1. Gateway → Config → Projects → **Import** → `EFC_Styles.zip`.
2. Use it one of three ways:
   - **Parent chain (recommended):** set `EFC_Styles` as the parent of `PID_Symbols`, and `PID_Symbols` as the parent of your HMI project. Every project inherits the styles. (Ignition allows one parent per project, so chain them.)
   - **Merge:** in Designer, open `EFC_Styles`, multi-select the Style Classes folders → right-click → Copy, then paste into your HMI project.
   - **File copy:** unzip `com.inductiveautomation.perspective/style-classes/*` into `<ignition>/data/projects/<YourProject>/com.inductiveautomation.perspective/style-classes/` and trigger a project scan.
3. Open view `Styles/_Catalog` to see every class on live components.

## Applying
Put one or more paths in a component's `props.style.classes`, separated by spaces, e.g.
`Text/Value Text/Mod/Right` or `Alarm/High/Outline Container/ValueBox`.
Bind it with an expression to switch by state, e.g.
`if({[.]Fault}, "State/Fault", if({[.]Run}, "State/Running", "State/Stopped"))`.

## Scaling
All sizes, padding and border widths are in **vh**, so text and lines scale with screen height:
1080p → 1×, 1440p → 1.33×, 2160p → 2×. 14 px body = `1.296vh`. Matches the AutoValve template and the screen layout standard.

## Type scale (px at 1080p)
| Class | px | Semantic class using it |
|---|---|---|
| `Text/Size/XXS` | 9 | `Text/Micro` |
| `Text/Size/XS` | 11 | `Text/Caption`, `Text/Units`, `Text/Status` |
| `Text/Size/S` | 12 | `Text/Label`, `Text/TagName`, `Text/MenuItem` |
| `Text/Size/M` | 14 | `Text/Body`, `Text/Value` |
| `Text/Size/L` | 16 | `Text/Subheader` |
| `Text/Size/XL` | 20 | `Text/Header`, `Text/ValueLarge` |
| `Text/Size/XXL` | 24 | `Text/Title` |
| `Text/Size/XXXL` | 32 | `Text/ValueHero` |

## Folders
- **Text/** — semantic roles (Title, Header, Body, Label, Value, Units, TagName, Status, Link, Code), plus `Size/`, `Weight/`, `Color/`, `Mod/` (italic, upper, align, ellipsis, wrap, tabular digits, no-select)
- **Container/** — Screen, Header, Menu, TrendPanel, AlarmBar, ProcessArea, Panel, Card, Inset, GroupBox, Toolbar, Popup, PopupHeader, Faceplate, ValueBox, Divider, Scroll
- **Button/** — Default, Primary, Subtle, Danger, Start, Stop, Small, Large, Icon, Momentary, Toggle On/Off, Nav, NavActive, Tab, TabActive (hover / pressed / focus / disabled states built in)
- **Input/** — Field, Setpoint, Dropdown, ReadOnly, Invalid, Pending, Check (editable values are blue)
- **Value/** — Normal, Setpoint, Output, BadQuality, Stale, Forced, Simulated
- **State/** & **Mode/** — Running (white), Stopped (gray), Transition, Fault (red), OutOfService, Unknown; Auto, Cascade, Manual, Local, Simulated
- **Indicator/** & **Bar/** — LEDs, Permissive (orange P), Interlock (red I), Badge, bar Track/Fill/FillAlarm/Marker
- **Alarm/** — Critical, High, Medium, Low, Diagnostic × {Fill, Unacked (blinking), Outline (3 px), Text}; Status ClearedUnacked / Shelved / Suppressed; Banner
- **Table/** — Header, Row, RowAlt, Cell, CellNumeric, Selected
- **Util/** — Pad S/M/L/None, Border, BorderDashed, Rounded, Shadow, Pointer, Disabled, Transparent, Blink, Highlight, Clip

## Notes
- Blinking classes (`Alarm/*/Unacked`, `Alarm/Status/ClearedUnacked`, `Util/Blink`) use the `efc-blink` keyframes in the project **stylesheet.css** (Perspective → Styles → Advanced Stylesheet). The stylesheet resource needs a recent 8.1 release (8.1.22+) and must live in the session project or one of its parents; on older versions those classes show solid instead of blinking.
- `Button/*` classes override the theme's blue button. Perspective button hover/active come from the class, so leave `props.style` on the button empty.
- Alarm colors: Critical red, High orange, Medium yellow, Low blue, Diagnostic purple. Never use alarm colors for anything else.
- Contrast checked (WCAG): body/label text ≥ 4.5:1; bold indicators (P, I) ≥ 3:1.
