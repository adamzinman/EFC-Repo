"""Zip projects/EFC_ProcessValues into an importable Ignition project (project.json at the zip root).
Output: dist/EFC_ProcessValues-<version>.zip  (dist/ is git-ignored; attach it to a release instead)."""
import os, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_pv import VERSION, PROJECT, REPO

def package():
    src = os.path.join(REPO, "projects", PROJECT)
    if not os.path.isfile(os.path.join(src, "project.json")):
        sys.exit(f"{src}/project.json missing - run tools/build_pv.py first")
    out = os.path.join(REPO, "dist", f"{PROJECT}-{VERSION}.zip")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    files = []
    for root, _, names in os.walk(src):
        files += [os.path.join(root, n) for n in names]
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(files):
            info = zipfile.ZipInfo(os.path.relpath(f, src).replace(os.sep, "/"), date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, open(f, "rb").read())
    return out

if __name__ == "__main__":
    print(package())
