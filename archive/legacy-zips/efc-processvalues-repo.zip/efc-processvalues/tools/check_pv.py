"""Static Ignition 8.1 check of projects/EFC_ProcessValues: JSON parses, expressions balanced, only known
expression functions, every {view.custom.*}/{view.params.*} reference exists, every style class exists
(in this project or in tools/efc_styles_classes.txt). Exit code 1 on problems."""
import json, os, re, sys
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJ = os.path.join(REPO, "projects", "EFC_ProcessValues")
class _Dir:
    """zipfile-like view of the project folder"""
    def namelist(self):
        out = []
        for root, _, files in os.walk(PROJ):
            out += [os.path.relpath(os.path.join(root, f), PROJ).replace(os.sep, "/") for f in files]
        return sorted(out)
    def read(self, n):
        return open(os.path.join(PROJ, n), "rb").read()
z = _Dir()
OK_FUNCS = {"if","case","isAlarmActiveFiltered","isNull","len","now","max","min","toBoolean","coalesce","toStr","substring",
            "lastIndexOf","numberFormat","isGood"}
EFC = set(re.findall(r"`([A-Za-z]+/[^`]+)`", open(os.path.join(REPO, "tools", "efc_styles_classes.txt")).read()))
problems = []
def walk_exprs(obj, path=""):
    if isinstance(obj, dict):
        if obj.get("type") == "expr" and "config" in obj: yield path, obj["config"]["expression"]
        for k, v in obj.items(): yield from walk_exprs(v, path + "/" + k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj): yield from walk_exprs(v, f"{path}[{i}]")
def strip_strings(e):
    return re.sub(r'"[^"]*"', '""', e)
def comps(node):
    yield node
    for c in node.get("children", []): yield from comps(c)
new_classes = {n.split("style-classes/")[1].rsplit("/style.json",1)[0] for n in z.namelist() if n.endswith("style.json")}
for n in z.namelist():
    if not n.endswith("view.json"): continue
    v = json.loads(z.read(n))
    customs = set(v.get("custom", {}))
    bound = {k.split(".",1)[1] for k in v.get("propConfig", {}) if k.startswith("custom.")}
    if customs != bound and v.get("custom"): problems.append((n, "custom defaults vs bindings", customs ^ bound))
    for p, e in walk_exprs(v):
        s = strip_strings(e)
        if s.count("(") != s.count(")"): problems.append((n, p, "paren"))
        if e.count('"') % 2: problems.append((n, p, "quote"))
        for f in re.findall(r"([A-Za-z_]+)\s*\(", s):
            if f not in OK_FUNCS: problems.append((n, p, "func " + f))
        for ref in re.findall(r"\{view\.custom\.([A-Za-z0-9_]+)\}", e):
            if ref not in customs: problems.append((n, p, "missing custom " + ref))
        for ref in re.findall(r"\{view\.params\.([A-Za-z0-9_]+)\}", e):
            if ref not in v["params"]: problems.append((n, p, "missing param " + ref))
        # class strings literal
        for lit in re.findall(r'"([^"]*)"', e):
            for tok in lit.split():
                if "/" in tok and not tok.startswith(("[","{")) and tok.split("/")[0] in ("PV","Alarm","Bar","Text","Value"):
                    if tok.endswith("/"): continue
                    if tok not in new_classes and tok not in EFC: problems.append((n, p, "class? " + tok))
    for c in comps(v["root"]):
        cls = c.get("props", {}).get("style", {}).get("classes", "")
        for tok in cls.split():
            if tok not in new_classes and tok not in EFC: problems.append((n, c["meta"]["name"], "static class? " + tok))
# dynamic class prefixes: PV/Chip/<P>, PV/Strip/<P>, Bar/Band/<P>
for pre in ("PV/Chip/", "PV/Strip/", "Bar/Band/"):
    for pr in ("Critical","High","Medium","Low","Diagnostic"):
        if pre+pr not in new_classes: problems.append(("classes", pre+pr, "missing"))
print("problems:", problems if problems else "none")
for n in z.namelist():
    if n.endswith(".json"): json.loads(z.read(n))
print(len(z.namelist()), "files;", sorted({n.split('/views/')[1].rsplit('/',1)[0] for n in z.namelist() if '/views/' in n}))

sys.exit(1 if problems else 0)
