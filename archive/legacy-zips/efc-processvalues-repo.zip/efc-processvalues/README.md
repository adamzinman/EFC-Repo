# EFC Process Value templates (Ignition Perspective 8.1)

Perspective templates that show one `DDT_Process_Value` instance: the tag name, the value with units, alarm letters (FLT · HH · H · L · LL · OVR · UNR · INH), and an alarm strip (A1) or range bar (B2). Version: see `CHANGELOG.md` (current **1.3.0**).

![preview](docs/preview.png)

## Repository layout
```
projects/EFC_ProcessValues/      Unzipped Ignition project (source of truth for the views & style classes)
  project.json                   parent = EFC_Styles, inheritable
  com.inductiveautomation.perspective/
    views/Templates/ProcessValues/{PV_StatusStrip, PV_RangeBar, _Demo}/
    style-classes/{PV, Alarm/Mod, Bar}/...
tags/PV_Demo_Tags.json           Demo UDT DDT_Process_Value_Demo + PV_Demo/PT001-PT005
tools/build_pv.py                Generator: rewrites projects/ , tags/ and docs/style-index.md
tools/check_pv.py                Static 8.1 check (expressions, references, style classes); exits 1 on problems
tools/package.py                 Builds dist/EFC_ProcessValues-<version>.zip (project.json at the zip root)
tools/efc_styles_classes.txt     EFC_Styles classes the views rely on (used by check_pv.py)
docs/                            preview.png, style-index.md
dist/                            build output, git-ignored
```

## Workflow
**Option 1: edit the generator (recommended).**
1. Change `tools/build_pv.py`.
2. Bump `VERSION` and `BUILD_TS`.
3. Run:
```bash
python3 tools/build_pv.py      # regenerate projects/, tags/, docs/style-index.md
python3 tools/check_pv.py      # must print "problems: none"
python3 tools/package.py       # -> dist/EFC_ProcessValues-<version>.zip
```
4. Commit the regenerated files together with the generator and a `CHANGELOG.md` entry.
5. Attach the zip from `dist/` to the git tag or release.

Resource timestamps are fixed per version, so rerunning the generator without changes produces no git diff.

**Option 2: edit in the Designer.**
1. Copy `projects/EFC_ProcessValues/` into `<ignition>/data/projects/`, or import the zip.
2. Edit the views in the Designer and save.
3. Copy the project folder back into the repo and commit.
4. Port the change into `tools/build_pv.py`. Otherwise the next generator run will overwrite your Designer edits.

**Deploying straight from git (no zip).** Copy `projects/EFC_ProcessValues/` to `<ignition>/data/projects/EFC_ProcessValues/` on the gateway. In 8.1, trigger a project scan with `system.project.requestScan()`, or restart the gateway.

### Views (Views → Templates → ProcessValues)
| View | Design | Size @1080p | Parameter |
|---|---|---|---|
| `Templates/ProcessValues/PV_StatusStrip` | A1: status strip | 104 × 54 (card 100 × 50) | `tagPath` |
| `Templates/ProcessValues/PV_RangeBar` | B2: range bar (A1 styling) | 104 × 54 (card 100 × 50) | `tagPath` |
| `Templates/ProcessValues/_Demo` | Both templates on the 5 demo tags, with PV entry fields and HW_Fault checkboxes | — | — |

`tagPath` is the full path to a `DDT_Process_Value` instance, for example `[default]Area1/PT002`. Everything else is read from the UDT:

| UDT member | Used for |
|---|---|
| `Name` | Tag text. If `Name` is empty, the last segment of `tagPath` is shown instead. |
| `Description` | Tooltip on the tag text |
| `PV` | The value (`#,##0.0`) |
| `Units` | Units text |
| `Eng_Min` / `Eng_Max` | Range-bar span and its tooltip (B2) |
| `HH/H/L/LL/SP` | Range-bar band edges (B2) |
| `HH/H/L/LL/Alarm` | The HH / H / L / LL letters, the A1 strip and the B2 bands |
| `Overrange` / `Underrange` | The OVR / UNR letters |
| `HW_Fault` | The FLT letter, the bad-quality value style and the magenta pointer |
| `*/Inhibit` | The INH letter (shown if any limit is inhibited) |

## Import into Ignition
1. **EFC_Styles** must already be on the gateway. It provides the `efc-blink` keyframes and the base text classes.
2. Build the zip (see below) or download it from the release, then go to Gateway → Config → Projects → **Import** → `EFC_ProcessValues-<version>.zip`. Keep the name `EFC_ProcessValues`. The views land in **Views/Templates/ProcessValues**.
3. To use the templates in your HMI project, pick one:
   - **Copy into an existing project (simplest):** in the Designer, open your HMI or PID_Symbols project and choose **File → Import**. Select `EFC_ProcessValues-<version>.zip` and tick the `Templates/ProcessValues` views and the `PV`, `Alarm/Mod` and `Bar` style classes.
   - **Inheritance:** make the chain `EFC_Styles → EFC_ProcessValues → PID_Symbols → HMI`. Ignition allows one parent per project.
4. (Optional demo) Tag Browser → select the `[default]` provider root → **Import Tags** → `tags/PV_Demo_Tags.json`. Then open `Templates/ProcessValues/_Demo`.

## Required UDT change: add an alarm on HW_Fault
In the real `DDT_Process_Value` UDT, select **HW_Fault** → **Alarms** → **Add** and set:
- **Name:** `HW_Fault`
- **Priority:** **High**
- **Mode:** Equality
- **Setpoint:** 1 (true)

Until this alarm exists, the FLT letter still appears whenever `HW_Fault` is true, but it stays solid, because there is nothing to acknowledge.

## Card style and size (v1.3)
- **Card:** 100 × 50 px at 1080p, vh-scaled (200 × 100 at 4K). White, 6 px corners, a 1 px #B3B3B3 border with a darker #8C8C8C bottom edge, and a soft shadow (`PV/Card`). ISA-101 normally limits shadows to popups; this one was chosen for contrast.
- **View size:** each view adds a transparent margin for the shadow (`PV/Shell`), so both views are **104 × 54**. Resize any instances already placed.
- **Text sizes:** tag 11 px (`PV/Tag`), value 18 px on A1 (`PV/Value`) and 16 px on B2 (`PV/ValueSmall`), units 10 px (`PV/Units`), letters 9 px on 12 px boxes.
- **Letter limit:** at most **2 letters** are shown, in the order FLT · HH · H · L · LL · OVR · UNR · INH.
  - Any further letters collapse into a **+N** box (`PV/Chip/More`). Its tooltip lists the hidden letters, and it blinks if a hidden alarm is unacknowledged.
  - When the letters need the room, the tag name is cut short with "…". The full description is in the tooltip.
- **B2 range labels:** the 0 / max end labels were removed. Hover the bar to see the range.

## Behaviour
| State | Letter | A1 strip | B2 band |
|---|---|---|---|
| Active, unacked | priority color, **blinking** | priority color, blinking | priority color, blinking |
| Active, acked | priority color, **solid** | solid | solid |
| Cleared, unacked | faded (25 %), steady | faded (only if nothing else is active) | faded |
| Cleared, acked | gone | gray | normal band |

- **Letter order:** always FLT · HH · H · L · LL · OVR · UNR · INH.
- **Letter color:** comes from the priority configured on each alarm.
- **Strip color:** FLT wins; otherwise the highest active priority.
- **Fixed colors:** FLT is always dark gray and INH never blinks.

## Notes and things to check on the gateway
- **Alarm state (v1.1):** each template makes one `system.alarm.queryStatus` call per second for `<tagPath>/*`, in a script transform on `custom.alm`. It returns a code for each of FLT/HH/H/L/LL/OVR/UNR.
  - v1.0 used `isAlarmActiveFiltered`, which showed as binding errors in the Designer.
  - Failures are logged to the gateway log under the `EFC_PV` logger.
  - To refresh less often on large screens, change `custom.tick` (`now(1000)`).
- **Alarm names:** the alarms can have any name. The script matches on the tag that carries the alarm: `HW_Fault`, `HH/Alarm`, `H/Alarm`, `L/Alarm`, `LL/Alarm`, `Overrange`, `Underrange`.
- **Blink on older gateways:** blinking needs the EFC_Styles advanced stylesheet, which requires 8.1.22 or later. On older 8.1 builds unacked alarms show solid.
- **Range bar:** bands are drawn from the four SPs whether or not a limit is enabled. The pointer clamps at the ends of the range.
- **INH:** the letter uses only the `Inhibit` bits. It ignores `Enabled`, so limits that are permanently unused don't flag.
- **Clicking:** clicking does nothing yet. A faceplate can be added later.
- **8.3:** the views use only standard 8.1 components and expression functions. Re-check the demo after the upgrade.
- **Not yet tested on a live gateway.** The views were statically checked (JSON, expression syntax, every bound property and style class) and the layout was checked in a browser approximation.
